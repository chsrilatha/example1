# bar-chart
Bar Chart introduction
